// ─── Call 1: Core qualitative evaluation (skills, roles, experience, grammar issues) ──────
// Fields returned: experienceLevel, presentSkills, missingSkills, jobRoles,
//   suggestions, grammarIssues
const analyseCoreResume = (resumeText, jobRole, jobDescription) => {
  const prompt = `
You are an expert ATS specialist and HR consultant across ALL industries. Auto-detect the candidate's field. Do NOT assume tech.

RESUME:
---
${resumeText}
---
Job Role: ${jobRole || 'Infer from resume'}
Job Description: ${jobDescription || 'Use standard requirements for detected profession'}

OUTPUT RULES:
- Return ONLY raw JSON. No markdown, no fences.
- All text values: max 120 characters.
- Arrays marked [MAX N] must have AT MOST N items.

QUALITATIVE EVALUATION:
1. Detect candidate's experienceLevel: one of Fresher / Junior / Mid-Level / Senior / Lead/Principal.
2. Extract presentSkills (skills explicitly found in the resume).
3. Identify missingSkills (key skills required for target role/field not found in resume).
4. Identify jobRoles (top 5-6 matching job titles with relevant emoji icons).
5. Identify grammarIssues (spelling, punctuation, tense inconsistency, passive voice, filler phrases, weak verbs, missing metrics). Categorize each using type: "spelling" | "punctuation" | "tense" | "passive_voice" | "filler_phrase" | "weak_verb" | "missing_metrics".
6. Provide suggestions (actionable improvement tips for the candidate).

OUTPUT JSON (fill every field):
{
  "experienceLevel": "",
  "presentSkills": ["skill1","skill2"],
  "missingSkills": ["m1","m2","m3","m4","m5"],
  "jobRoles": [
    {"title":"","icon":""}
  ],
  "grammarIssues": [
    {"original":"","corrected":"","type":"spelling","text":"","fix":""}
  ],
  "suggestions": ["s1","s2","s3","s4","s5","s6"]
}

ARRAY LIMITS: presentSkills [MAX 20], missingSkills [MAX 6], jobRoles [MIN 5, MAX 6], grammarIssues [MIN 4, MAX 5], suggestions [MIN 6, MAX 7].
`;
  return prompt;
};

// ─── Call 2: Deep qualitative section analysis + ATS checklist ───────────────────
// Fields returned: sectionsAnalysis, atsChecklist, projectsFeedback, certifications
const analyseDeepResume = (resumeText) => {
  const prompt = `
You are an expert ATS specialist and HR consultant across ALL industries. Auto-detect the candidate's field.

RESUME:
---
${resumeText}
---

OUTPUT RULES:
- Return ONLY raw JSON. No markdown, no fences.
- All text values: max 120 characters.
- Arrays marked [MAX N] must have AT MOST N items.

SECTIONS ANALYSIS:
- List every section that ACTUALLY exists in the resume (exact heading). No invented, no omitted.
- Every entry: section, quality (Strong/Adequate/Weak/Minimal), note (<=100 chars), details (or null).

UNIVERSAL ITEM-LEVEL QUALITY + SECTION DOWNGRADE (applies to every itemized section):
- For any section with 'details.items', compute per item:
  - 'unresolvedFlags': array of strings (max 3 per item): e.g. 'missing quantified results',
    'impact not specified', 'vague description', 'missing dates', 'unclear scope', 'no metrics'.
  - 'unresolvedFlagCount': integer = unresolvedFlags.length.
- Compute section-level: itemsWithUnresolvedFlags (count where unresolvedFlagCount > 0),
  majorityUnresolved (true if itemsWithUnresolvedFlags > items.length / 2).

CRITICAL QUALITY RULE:
- If majorityUnresolved is true: quality MUST NOT be 'Strong' (downgrade to Adequate or Weak).

DETAILS RULES (by section type):

Skills section -> details:
  totalCount (integer), groups: [MAX 4] { category: '<name from THIS resume>', items: [MAX 5] }
  (Categories must reflect this resume's field — never tech-only defaults.)

Projects/Achievements/Portfolio/Campaigns -> details:
  totalCount (integer), items: [MAX 4] { name: '<=60 chars', impact: '<metric or Not specified>',
  unresolvedFlags: [...], unresolvedFlagCount: integer }

Education -> details:
  relevance: High/Medium/Low, gpa: '<value>' or null, note: '<=100 chars'

Employment/Experience/Work History -> details:
  totalYears: '<e.g. 4 years 3 months>', growthTrajectory: Progressive/Lateral/Mixed/Single Role,
  trajectoryNote: '<=100 chars',
  items: [MAX 4] { name: '<=60 chars', dateRange: '<=60 chars or Not specified',
  unresolvedFlags: [...], unresolvedFlagCount: integer }

Certifications/Licenses -> details:
  totalCount (integer), items: [MAX 4] { name: '<=60 chars', industryRecognized: true/false,
  relevance: High/Medium/Low, unresolvedFlags: [...], unresolvedFlagCount: integer }

Languages -> details:
  items: [MAX 5] { language: '<name>', proficiency: 'Native/Fluent/Professional/Conversational/Basic',
  unresolvedFlags: [...], unresolvedFlagCount: integer }

All other sections -> details: null

ATS PARSABILITY CHECKLIST — return exactly 4 items based ONLY on structure/formatting,
NEVER on profession, industry, or skill content:

1. check: 'Tables or Columns Detected'
   Detect scrambled text, unusual mid-line spacing, content jumping topics mid-line
   (symptoms of multi-column or table layout ATS parsers misread).
   passed: true = text flows logically; false = layout artifacts detected.

2. check: 'Special Characters / Icons'
   Detect unusual Unicode bullets/labels, broken characters, or contact fields
   with no text label (icon-only labels ATS cannot parse).
   passed: true = no problematic symbols; false = icon-only labels or broken chars found.

3. check: 'Standard Section Headers'
   Conventional: Summary/Profile/Objective, Experience/Work History, Education,
   Skills/Competencies, Certifications, Projects, Languages.
   Creative/unusual headers (e.g. 'My Journey', 'What I Bring') confuse ATS.
   passed: true = all headers conventional; false = one or more unconventional headers.

4. check: 'Contact Info Placement'
   Contact info (name, phone, email, location) must appear in the main body text.
   Info isolated in a tiny top block or absent may mean it is in a PDF header ATS skips.
   passed: true = contact info present in readable body; false = isolated or absent.

Each item shape: { "check": "<name>", "passed": true/false, "detail": "<one sentence <=120 chars>" }

OUTPUT JSON (fill every field):
{
  "sectionsAnalysis": [
    { "section": "", "quality": "", "note": "", "details": null }
  ],
  "projectsFeedback": ["feedback"],
  "certifications": ["evaluation"],
  "atsChecklist": [
    {"check":"Tables or Columns Detected","passed":true,"detail":""},
    {"check":"Special Characters / Icons","passed":true,"detail":""},
    {"check":"Standard Section Headers","passed":true,"detail":""},
    {"check":"Contact Info Placement","passed":true,"detail":""}
  ]
}

ARRAY LIMITS: projectsFeedback [MAX 5], certifications [MAX 5], atsChecklist [EXACTLY 4].
`;
  return prompt;
};

module.exports = { analyseCoreResume, analyseDeepResume };